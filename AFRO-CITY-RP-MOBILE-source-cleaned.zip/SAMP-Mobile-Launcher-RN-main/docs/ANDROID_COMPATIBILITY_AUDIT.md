# Android Compatibility Audit

This audit is based on the supplied launcher source archive.

## Confirmed baseline

- React Native 0.70.3; React 18.1.0
- Android min SDK 21, compile SDK 33, target SDK 28
- Android Gradle Plugin 7.2.2; Gradle wrapper 7.5.1
- Application ID `com.touch.mobile.dark`
- The app module explicitly filters native builds to `armeabi-v7a`

## Native game libraries

The supplied archive contains `libSCAnd.so`, `libGTASA.so`, `libbass.so`, `libsamp.so`, and `libImmEmulatorJ.so` only in `android/app/src/main/jniLibs/armeabi-v7a/`. No `arm64-v8a` copies were supplied.

## Compatibility implications

Adding `arm64-v8a` to `abiFilters` alone will not create a working 64-bit game client. The GTA SA / SA-MP native libraries and every required native dependency need genuine compatible ARM64 builds. Do not copy or rename ARM32 binaries into an ARM64 directory.

The React Native and Android build stack should be upgraded as a coordinated migration, validating native modules at each step. Raising target SDK also requires testing storage, notifications, background execution, and APK installation/update flows.

## Recommended sequence

1. Establish a reproducible build with the current dependency and toolchain versions.
2. Add CI build checks and document JDK, Android SDK, NDK, and package-manager requirements.
3. Upgrade React Native and Android Gradle components in small steps.
4. Test downloads, storage, notifications, install/update behavior, audio, controls, server query, and game startup on representative devices.
5. Obtain official ARM64 builds for all native game libraries before claiming 64-bit game support.

## Release gate

Do not advertise full ARM64 game support until an APK with real `arm64-v8a` game-client libraries is built and tested on a 64-bit-only Android device.

## Configuration and signing

Copy `.env.example` to `.env` and fill in deployment-specific values locally. `.env` is ignored by Git. Keep release signing keys and private credentials outside the repository. Review Firebase project restrictions and API-key restrictions before public distribution.
